package invaders.engine;

import java.util.ArrayList;
import java.util.List;

import invaders.ConfigReader;
import invaders.builder.BunkerBuilder;
import invaders.builder.Director;
import invaders.builder.EnemyBuilder;
import invaders.factory.EnemyProjectile;
import invaders.factory.Projectile;
import invaders.gameobject.Bunker;
import invaders.gameobject.Enemy;
import invaders.gameobject.GameObject;
import invaders.entities.Player;
import invaders.rendering.Renderable;
import invaders.single.SingleGameState;
import org.json.simple.JSONObject;

/**
 * This class manages the main loop and logic of the game
 */
public class GameEngine {
	private List<GameObject> gameObjects = new ArrayList<>(); // A list of game objects that gets updated each frame
	private List<GameObject> pendingToAddGameObject = new ArrayList<>();
	private List<GameObject> pendingToRemoveGameObject = new ArrayList<>();

	private List<Renderable> pendingToAddRenderable = new ArrayList<>();
	private List<Renderable> pendingToRemoveRenderable = new ArrayList<>();

	private List<Renderable> renderables =  new ArrayList<>();

	private Player player;

	private boolean left;
	private boolean right;
	private int gameWidth;
	private int gameHeight;
	private int timer = 45;
    private int playerScore = 0;
	private List<Integer> playerScoreList = new ArrayList<>();
	private List<Integer> timerList = new ArrayList<>();

	private SingleGameState myGameState;

	public GameEngine(String config){
		myGameState = SingleGameState.getInstance();
		// Read the config here
		ConfigReader.parse(config);

		// Get game width and height
		gameWidth = ((Long)((JSONObject) ConfigReader.getGameInfo().get("size")).get("x")).intValue();
		gameHeight = ((Long)((JSONObject) ConfigReader.getGameInfo().get("size")).get("y")).intValue();

		//Get player info
		this.player = new Player(ConfigReader.getPlayerInfo());
		renderables.add(player);


		Director director = new Director();
		BunkerBuilder bunkerBuilder = new BunkerBuilder();
		//Get Bunkers info
		for(Object eachBunkerInfo:ConfigReader.getBunkersInfo()){
			Bunker bunker = director.constructBunker(bunkerBuilder, (JSONObject) eachBunkerInfo);
			gameObjects.add(bunker);
			renderables.add(bunker);
		}


		EnemyBuilder enemyBuilder = new EnemyBuilder();
		//Get Enemy info
		for(Object eachEnemyInfo:ConfigReader.getEnemiesInfo()){
			Enemy enemy = director.constructEnemy(this,enemyBuilder,(JSONObject)eachEnemyInfo);
			gameObjects.add(enemy);
			renderables.add(enemy);
		}

	}


	public GameEngine(){

	}

	public GameEngine copyGameEngine(){
		GameEngine bkEngine = new GameEngine();

		return bkEngine;
	}

	public void undo(){
		int index = (renderables.size() / 3) * 2;
		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("Enemy")){
				((Enemy)renderable).setOldState(index);
			}
		}
		this.playerScore = playerScoreList.get(0);
		this.timer = timerList.get(0);

	}

	public void cheatSlowAlien(){
		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("Enemy")){
				((Enemy)renderable).cheatSlow();
			}
		}

	}

	public void cheatSlowEnemyProjectile(){
		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("EnemyProjectile")){
				((EnemyProjectile)renderable).cheatSlow();
			}
		}

	}


	public void cheatFastAlien(){
		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("Enemy")){
				((Enemy)renderable).cheatFast();
			}
		}
	}

	public void cheatFastEnemyProjectile(){
		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("EnemyProjectile")){
				((EnemyProjectile)renderable).cheatFast();
			}
		}

	}

	/**
	 * Updates the game/simulation
	 */
	public void update(){
		timer+=1;

		movePlayer();

		for(GameObject go: gameObjects){
			go.update(this);
		}

		for(int i = 0; i < renderables.size(); ++i){
			Renderable renderable = renderables.get(i);
			if(renderable.getRenderableObjectName().equals("Enemy")){
				((Enemy)renderable).keepCurrentState();
			}
		}

		this.playerScoreList.add(playerScore);
		this.timerList.add(timer);

		for (int i = 0; i < renderables.size(); i++) {
			Renderable renderableA = renderables.get(i);
			for (int j = i+1; j < renderables.size(); j++) {
				Renderable renderableB = renderables.get(j);

				if((renderableA.getRenderableObjectName().equals("Enemy") && renderableB.getRenderableObjectName().equals("EnemyProjectile"))
						||(renderableA.getRenderableObjectName().equals("EnemyProjectile") && renderableB.getRenderableObjectName().equals("Enemy"))||
						(renderableA.getRenderableObjectName().equals("EnemyProjectile") && renderableB.getRenderableObjectName().equals("EnemyProjectile"))){
				}else{
					if(renderableA.isColliding(renderableB) && (renderableA.getHealth()>0 && renderableB.getHealth()>0)) {
						renderableA.takeDamage(1);
						renderableB.takeDamage(1);
						int thisScore = computeScore(renderableA, renderableB);
						playerScore += thisScore;

					}
				}
			}
		}


		// ensure that renderable foreground objects don't go off-screen
		int offset = 1;
		for(Renderable ro: renderables){
			if(!ro.getLayer().equals(Renderable.Layer.FOREGROUND)){
				continue;
			}
			if(ro.getPosition().getX() + ro.getWidth() >= gameWidth) {
				ro.getPosition().setX((gameWidth - offset) -ro.getWidth());
			}

			if(ro.getPosition().getX() <= 0) {
				ro.getPosition().setX(offset);
			}

			if(ro.getPosition().getY() + ro.getHeight() >= gameHeight) {
				ro.getPosition().setY((gameHeight - offset) -ro.getHeight());
			}

			if(ro.getPosition().getY() <= 0) {
				ro.getPosition().setY(offset);
			}
		}

	}

	public int computeScore(Renderable renderableA, Renderable renderableB){
		Renderable realEnemy = null;
		if(renderableA.getRenderableObjectName().equals("Enemy") || renderableA.getRenderableObjectName().equals("EnemyProjectile"))
		{
			realEnemy = renderableA;
		}
		else {
			realEnemy = renderableB;
		}
		int score = 0;
		if(realEnemy.getRenderableObjectName().equals("Enemy")) {
			if (((Enemy) realEnemy).getSlow_or_fast().equals("slow_straight")) {
				score = 3;
			}
			if (((Enemy) realEnemy).getSlow_or_fast().equals("fast_straight")) {
				score = 4;
			}
		}
		else if(realEnemy.getRenderableObjectName().equals("EnemyProjectile")){
			if(((EnemyProjectile)realEnemy).getStrategy().equals("slow_straight")){
				score = 1;
			}
			if(((EnemyProjectile)realEnemy).getStrategy().equals("fast_straight")){
				score = 2;
			}
		}
		System.out.println(score);
		return  score;
	}

	public List<Renderable> getRenderables(){
		return renderables;
	}

	public List<GameObject> getGameObjects() {
		return gameObjects;
	}
	public List<GameObject> getPendingToAddGameObject() {
		return pendingToAddGameObject;
	}

	public List<GameObject> getPendingToRemoveGameObject() {
		return pendingToRemoveGameObject;
	}

	public List<Renderable> getPendingToAddRenderable() {
		return pendingToAddRenderable;
	}

	public List<Renderable> getPendingToRemoveRenderable() {
		return pendingToRemoveRenderable;
	}


	public void leftReleased() {
		this.left = false;
	}

	public void rightReleased(){
		this.right = false;
	}

	public void leftPressed() {
		this.left = true;
	}
	public void rightPressed(){
		this.right = true;
	}

	public boolean shootPressed(){
		if(timer>45 && player.isAlive()){
			Projectile projectile = player.shoot();
			gameObjects.add(projectile);
			renderables.add(projectile);
			timer=0;
			return true;
		}
		return false;
	}

	private void movePlayer(){
		if(left){
			player.left();
		}

		if(right){
			player.right();
		}
	}

	public int getGameWidth() {
		return gameWidth;
	}

	public int getGameHeight() {
		return gameHeight;
	}

	public Player getPlayer() {
		return player;
	}

	public int getPlayerScore(){return playerScore;}
}
