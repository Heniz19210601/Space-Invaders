package invaders.physics;

import java.util.ArrayList;
import java.util.List;

/**
 * A utility class for storing position information
 */
public class Vector2D {

	private double x;
	private double y;

	private List<Double> xList = new ArrayList<>();
	private List<Double> yList = new ArrayList<>();

	public Vector2D(double x, double y){
		this.x = x;
		this.y = y;
	}

	public double getX(){
		return this.x;
	}

	public double getY(){
		return this.y;
	}

	public void setX(double x){
		xList.add(this.x);
		this.x = x;
	}

	public void setY(double y){
		yList.add(this.y);
		this.y = y;
	}

	public void undo(){
		this.x = xList.get(0);
		this.y = yList.get(0);
	}
}
