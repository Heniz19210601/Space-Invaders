package invaders.single;

import invaders.engine.GameEngine;
import invaders.engine.GameWindow;

public class SingleGameLevelHard {
    private static  SingleGameLevelHard instance = new SingleGameLevelHard();
    private GameWindow window;

    private SingleGameLevelHard(){
        GameEngine model = new GameEngine("src/main/resources/config_hard.json");
        GameWindow window = new GameWindow(model);
    }

    public static SingleGameLevelHard getInstance(){
        return instance;

    }



}
