package invaders.single;

import invaders.engine.GameEngine;
import invaders.engine.GameWindow;

public class SingleGameLevelEasy {
    private static  SingleGameLevelEasy instance = new SingleGameLevelEasy();
    private GameWindow  window;

    private SingleGameLevelEasy(){
        GameEngine model = new GameEngine("src/main/resources/config_easy.json");
        GameWindow window = new GameWindow(model);
    }

    public GameWindow getWindow(){return window;}

    public static SingleGameLevelEasy getInstance(){
        return instance;

    }



}
