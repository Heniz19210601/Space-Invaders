package invaders.single;


import java.util.ArrayList;
import java.util.List;

public class SingleGameState{

    private static  SingleGameState instance = new SingleGameState();

    private List<Integer> playerScoreList = new ArrayList<>();
    private List<Integer> timerList = new ArrayList<>();

    private SingleGameState(){
    }

    public static SingleGameState getInstance(){
        return instance;

    }

    public void showMessage(){
        System.out.println("Hello World!");
    }
}