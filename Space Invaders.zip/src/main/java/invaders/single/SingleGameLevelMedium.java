package invaders.single;

import invaders.engine.GameEngine;
import invaders.engine.GameWindow;



public class SingleGameLevelMedium{
    private static  SingleGameLevelMedium instance = new SingleGameLevelMedium();
    private GameWindow window;

    private SingleGameLevelMedium(){
        GameEngine model = new GameEngine("src/main/resources/config_medium.json");
        GameWindow window = new GameWindow(model);
    }

    public static SingleGameLevelMedium getInstance(){
        return instance;

    }



}
