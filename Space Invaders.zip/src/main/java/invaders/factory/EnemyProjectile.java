package invaders.factory;

import invaders.engine.GameEngine;
import invaders.physics.Collider;
import invaders.physics.Vector2D;
import invaders.strategy.FastProjectileStrategy;
import invaders.strategy.ProjectileStrategy;
import invaders.strategy.SlowProjectileStrategy;
import javafx.scene.image.Image;

public class EnemyProjectile extends Projectile{
    private ProjectileStrategy strategy;

    public EnemyProjectile(Vector2D position, ProjectileStrategy strategy, Image image) {
        super(position,image);
        this.strategy = strategy;
    }

    @Override
    public void update(GameEngine model) {
        strategy.update(this);

        if(this.getPosition().getY()>= model.getGameHeight() - this.getImage().getHeight()){
            this.takeDamage(1);
        }

    }
    @Override
    public String getRenderableObjectName() {
        return "EnemyProjectile";
    }

    public String getStrategy(){
        if(strategy instanceof FastProjectileStrategy){
            return "fast_straight";
        }
        else if(strategy instanceof SlowProjectileStrategy){
            return "slow_straight";
        }
        return null;
    }

    public void cheatSlow() {
        if (strategy instanceof SlowProjectileStrategy) {
            this.setHealth(0);
        }
    }


    public void cheatFast() {
        if (strategy instanceof FastProjectileStrategy) {
            this.setHealth(0);
        }
    }
}
