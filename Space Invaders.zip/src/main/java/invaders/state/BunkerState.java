package invaders.state;
public interface BunkerState {
    public void takeDamage();
}
