package invaders.Observer;

public class ScoreObserver extends  Observer{
    @Override
    public void update() {

    }
}
