package invaders.Observer;

import java.util.ArrayList;
import java.util.List;

public class Subject {
    private int score;
    private int timer;
    private List<Observer> observers = new ArrayList<>();

    public void setScore(int score) {
        this.score = score;
    }

    public void setTimer(int time)
    {
        this.timer = time;
    }

    public int getScore()
    {
        return this.score;
    }

    public int getTimer(){
        return this.timer;
    }


    public void attach(Observer observer){
        observers.add(observer);
    }

    public void notifyAllObservers(){
        for (Observer observer : observers) {
            observer.update();
        }
    }
}
