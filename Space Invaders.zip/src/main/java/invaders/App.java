package invaders;

import invaders.single.SingleGameLevelEasy;
import invaders.single.SingleGameLevelHard;
import invaders.single.SingleGameLevelMedium;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import invaders.engine.GameEngine;
import invaders.engine.GameWindow;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.util.Map;

public class App extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        //Creating a menu
        //Setting the stage
        MenuBar menuBar = constructMenu(primaryStage);
        Group root = new Group(menuBar);
        Scene scene = new Scene(root, 595, 200, Color.BEIGE);
        primaryStage.setTitle("Menu Example");
        primaryStage.setScene(scene);
        primaryStage.show();


    }


    public MenuBar constructMenu(Stage primaryStage){

        Menu fileMenu = new Menu("choose difficult");
        //Creating menu Items
        MenuItem item1 = new MenuItem("easy");
        MenuItem item2 = new MenuItem("medium");
        MenuItem item3 = new MenuItem("hard");
        item1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                SingleGameLevelEasy easy =  SingleGameLevelEasy.getInstance();
                showWindows(primaryStage, "src/main/resources/config_easy.json");
            }
        });

        item2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                SingleGameLevelMedium medium=  SingleGameLevelMedium.getInstance();
                showWindows(primaryStage, "src/main/resources/config_medium.json");
            }
        });

        item3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                SingleGameLevelHard hard =  SingleGameLevelHard.getInstance();
                showWindows(primaryStage, "src/main/resources/config_hard.json");
            }
        });
        //Adding all the menu items to the menu
        fileMenu.getItems().addAll(item1, item2, item3);
        //Creating a menu bar and adding menu to it.
        MenuBar menuBar = new MenuBar(fileMenu);
        menuBar.setTranslateX(200);
        menuBar.setTranslateY(20);
        return menuBar;
    }

    public void showWindows(Stage primaryStage, String config){
        GameEngine model = new GameEngine(config);
        GameWindow window = new GameWindow(model);
        window.run();
        primaryStage.setTitle("Space Invaders");
        primaryStage.setScene(window.getScene());
        primaryStage.show();
        window.run();
    }
}
